bool_bool_bool means snv(o/x)_savgol(o/x)_differential(o/x)

ex) snv(x)_savgol(o)_differential(o) == 0_1_1